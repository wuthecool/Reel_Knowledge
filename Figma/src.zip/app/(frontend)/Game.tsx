'use client'

import { FormEvent, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import Image from 'next/image'
import { getInventory, saveCatch, type InventoryCatch } from './actions'
import { questionBank as firstQuestionBank, type Question } from './questionBank'
import { additionalQuestionBank } from './questionBank2'

type Rarity = 'common' | 'rare' | 'epic' | 'legendary'
type Screen = 'title' | 'casting' | 'intro' | 'question' | 'evaluating' | 'feedback' | 'reeling' | 'result'
const questionBank = [...firstQuestionBank, ...additionalQuestionBank]
const underwaterScreens: Screen[] = ['question', 'evaluating', 'feedback', 'reeling']
const soundEffects = {
  failed: '/game-assets/failedreel.mp3',
  perfect: '/game-assets/goldenmack.mp3',
  zero: '/game-assets/zeropoints.mp3',
  good: '/game-assets/goodcatch.mp3',
  great: '/game-assets/greatcatch.mp3',
  start: '/game-assets/startreeling.mp3',
  success: '/game-assets/successreel.mp3',
} as const

type Target = { name: string; rarity: Rarity; threshold: number }
const targets: Target[] = [
  { name: 'Moon Jelly Goby', rarity: 'common', threshold: 18 },
  { name: 'Atlantic Herring', rarity: 'common', threshold: 20 },
  { name: 'Atlantic Cod', rarity: 'common', threshold: 19 },
  { name: 'Bluegill', rarity: 'common', threshold: 18 },
  { name: 'Common Carp', rarity: 'common', threshold: 20 },
  { name: 'European Perch', rarity: 'common', threshold: 19 },
  { name: 'Rainbow Trout', rarity: 'common', threshold: 21 },
  { name: 'Channel Catfish', rarity: 'common', threshold: 20 },
  { name: 'Goldfish', rarity: 'common', threshold: 18 },
  { name: 'European Sardine', rarity: 'common', threshold: 19 },
  { name: 'Bluefin Trevally', rarity: 'rare', threshold: 30 },
  { name: 'Leafy Seadragon', rarity: 'rare', threshold: 32 },
  { name: 'Mandarinfish', rarity: 'rare', threshold: 31 },
  { name: 'Banggai Cardinalfish', rarity: 'rare', threshold: 33 },
  { name: 'Clown Triggerfish', rarity: 'rare', threshold: 32 },
  { name: 'Longhorn Cowfish', rarity: 'rare', threshold: 34 },
  { name: 'Weedy Seadragon', rarity: 'rare', threshold: 35 },
  { name: 'Phantom Knifefish', rarity: 'epic', threshold: 44 },
  { name: 'Giant Isopod', rarity: 'epic', threshold: 46 },
  { name: 'Goblin Shark', rarity: 'epic', threshold: 47 },
  { name: 'Coelacanth', rarity: 'epic', threshold: 48 },
  { name: 'Ocean Sunfish', rarity: 'epic', threshold: 46 },
  { name: 'Giant Freshwater Stingray', rarity: 'epic', threshold: 50 },
  { name: 'Giant Oarfish', rarity: 'legendary', threshold: 60 },
  { name: 'Golden Mahseer', rarity: 'legendary', threshold: 58 },
  { name: 'Whale Shark', rarity: 'legendary', threshold: 62 },
  { name: 'Greenland Shark', rarity: 'legendary', threshold: 64 },
  { name: 'Beluga Sturgeon', rarity: 'legendary', threshold: 61 },
]

function rollTarget(previousIndex: number, avoidPrevious: boolean, forcedRarity?: Rarity) {
  const roll = Math.random()
  const rarity: Rarity = forcedRarity ?? (roll < .5
    ? 'common'
    : roll < .8
      ? 'rare'
      : roll < .95
        ? 'epic'
        : 'legendary')
  const candidates = targets
    .map((target, index) => ({ target, index }))
    .filter(({ target, index }) => target.rarity === rarity && (!avoidPrevious || index !== previousIndex))
  return candidates[Math.floor(Math.random() * candidates.length)].index
}

const rarityLabels: Record<Rarity, string> = {
  common: 'COMMON',
  rare: 'RARE',
  epic: 'EPIC',
  legendary: 'LEGENDARY',
}

function RarityTag({ rarity }: { rarity: Rarity }) {
  return <span className={`rarity rarity--${rarity}`}>{rarityLabels[rarity]}</span>
}

function GameButton({
  children,
  variant = 'primary',
  onClick,
  disabled,
  type = 'button',
}: {
  children: React.ReactNode
  variant?: 'primary' | 'secondary' | 'ghost'
  onClick?: () => void
  disabled?: boolean
  type?: 'button' | 'submit'
}) {
  return (
    <button className={`button button--${variant}`} onClick={onClick} disabled={disabled} type={type}>
      {children}
    </button>
  )
}

function CoolerButton({ count, onClick, compact = false }: { count: number; onClick: () => void; compact?: boolean }) {
  return (
    <button className={`cooler-button ${compact ? 'cooler-button--compact' : ''}`} onClick={onClick} type="button" aria-label={`Open cooler with ${count} caught fish`}>
      <Image src="/game-assets/cooler-button-full.png" alt="" width={94} height={94} unoptimized />
      <span>COOLER</span>
      <b>{count}</b>
    </button>
  )
}

function Neptune({ pose = 'asking' }: { pose?: 'greeting' | 'asking' | 'happy' | 'sad' | 'casting' | 'thinking' }) {
  const casting = pose === 'casting'
  const thinking = pose === 'thinking'
  return (
    <div className={`neptune neptune--${pose}`} aria-label={`King Neptune, ${pose} pose`}>
      {casting && <div className="magic-ring" />}
      {thinking && <span className="thought thought--one">·</span>}
      {thinking && <span className="thought thought--two">?</span>}
      <Image className="neptune-sprite" src="/game-assets/neptune.png" alt="" width={54} height={54} unoptimized />
    </div>
  )
}

function UnderwaterLine({ target, points }: { target: Target; points: number }) {
  const progress = Math.min(1, points / target.threshold)
  const lineStyle = { '--reel-position': `${22 + progress * 50}%` } as CSSProperties
  return (
    <div className="underwater-stage" aria-label="Underwater fishing line">
      <div className="pixel-light pixel-light--one" />
      <div className="pixel-light pixel-light--two" />
      <div className="bubble-field">·　°　·<br />　·　°<br />°　　·</div>
      <div className="fishing-line" style={lineStyle}>
        <div className="reel-drum"><i /></div>
        <div className="line-segment" />
        <div className="reel-catch">
          <span className="pixel-hook">J</span>
          <span
            className={`line-fish line-fish--${target.rarity}`}
            role="img"
            aria-label={`${target.rarity} target fish attached to the line`}
          />
          <span className="reel-depth">{Math.round(progress * 100)}%</span>
        </div>
      </div>
      <div className="sea-floor"><i /><i /><i /><i /></div>
    </div>
  )
}

function CastingSequence({ target }: { target: Target }) {
  return (
    <div className="scene scene--casting" aria-label={`Casting for ${target.name}`}>
      <span className="casting-title">CASTING...</span>
      <Rod state="cast" />
      <svg className="cast-arc" viewBox="0 0 1200 600" shapeRendering="crispEdges" aria-hidden="true">
        <polyline points="285,210 360,210 360,180 455,180 455,155 575,155 575,180 690,180 690,205 805,205 805,235 900,235 900,360" />
      </svg>
      <div className="cast-splash"><i /><i /><i /></div>
      <div className="cast-hook">J</div>
      <span className={`cast-fish cast-fish--${target.rarity}`} aria-hidden="true" />
      <div className="bite-burst">!</div>
    </div>
  )
}

function Rod({ state = 'idle' }: { state?: 'idle' | 'cast' | 'tension' | 'caught' | 'slack' }) {
  return (
    <div className={`rod rod--${state}`} aria-label={`Fishing rod, ${state}`}>
      <svg viewBox="0 0 300 460" shapeRendering="crispEdges" aria-hidden="true">
        <polyline className="rod-stick" points="42,426 42,390 54,390 54,344 66,344 66,300 82,300 82,258 100,258 100,218 120,218 120,184 142,184 142,154 166,154 166,128 190,128 190,104 222,104 222,79" />
        <polyline className="rod-line" points="222,79 246,79 246,112 264,112 264,345" />
        <rect className="reel" x="48" y="312" width="50" height="50" />
        <rect className="reel-inner" x="66" y="330" width="14" height="14" />
        <polyline className="handle" points="54,379 54,411 32,411 32,449" />
        <rect className="bobber" x="257" y="344" width="14" height="14" />
      </svg>
    </div>
  )
}

function ProgressMeter({ points, threshold = 60 }: { points: number; threshold?: number }) {
  const width = Math.min(100, (points / threshold) * 100)
  return (
    <div className="meter-wrap">
      <div className="meter-labels">
        <span>Rod power</span>
        <strong>{points} / {threshold} pts</strong>
      </div>
      <div className="meter" role="progressbar" aria-valuenow={points} aria-valuemax={threshold}>
        <div className="meter-fill" style={{ width: `${width}%` }} />
        <div className="threshold-marker"><span>REEL IN!</span></div>
      </div>
    </div>
  )
}

function Hud({ points, question, target, onInventory, count }: { points: number; question: number; target: Target; onInventory: () => void; count: number }) {
  return (
    <div className="hud">
      <div className="hud-item"><span className="hud-label">QUESTION</span><strong>{Math.min(question + 1, 3)} <small>/ 3</small></strong></div>
      <div className="hud-target">
        <span className="hud-label">TARGET</span>
        <strong>{target.name}</strong>
        <RarityTag rarity={target.rarity} />
        <span className="needs">needs {target.threshold} pts</span>
      </div>
      <div className="hud-item hud-score"><CoolerButton count={count} onClick={onInventory} compact /><strong>{points} <small>PTS</small></strong></div>
    </div>
  )
}

function Dialogue({ children, eyebrow }: { children: React.ReactNode; eyebrow?: string }) {
  return (
    <div className="dialogue">
      <span className="dialogue-name">{eyebrow || 'KING NEPTUNE'}</span>
      {children}
    </div>
  )
}

function ScoreBreakdown({ answers }: { answers: Answer[] }) {
  return (
    <div className="score-list">
      {answers.map((answer, index) => (
        <div className="score-row" key={`${answer.name}-${index}`}>
          <span className="row-number">{index + 1}</span>
          <strong>{answer.name}</strong>
          {answer.valid ? <RarityTag rarity={answer.rarity} /> : <span className="rarity rarity--invalid">INVALID</span>}
          <b>+{answer.points}</b>
        </div>
      ))}
    </div>
  )
}

type Answer = { name: string; points: number; rarity: Rarity; reaction: string; valid: boolean }
type Correction = { query: string; matches: string[] }

function Inventory({ items, onClose }: { items: InventoryCatch[]; onClose: () => void }) {
  return (
    <div className="overlay">
      <div className="inventory">
        <div className="guide-head">
          <div><span className="kicker">NEPTUNE’S COOLER</span><h2>Caught fish</h2></div>
          <button className="close-button" onClick={onClose} aria-label="Close inventory">×</button>
        </div>
        {items.length ? <div className="inventory-list">{items.map((item) => (
          <div className="inventory-row" key={item.id}>
            <div><strong>{item.fishName}</strong><span>{new Date(item.caughtAt).toLocaleDateString()}</span></div>
            <RarityTag rarity={item.rarity} /><b>{item.points} pts</b>
          </div>
        ))}</div> : <div className="empty-keep"><strong>Your cooler is empty</strong><p>Land a target fish and its name will be stored here.</p></div>}
      </div>
    </div>
  )
}

function normalizeAnswer(value: string) {
  return value.trim().toLocaleLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ')
}

function editDistance(left: string, right: string) {
  const previous = Array.from({ length: right.length + 1 }, (_, index) => index)
  for (let leftIndex = 1; leftIndex <= left.length; leftIndex++) {
    const current = [leftIndex]
    for (let rightIndex = 1; rightIndex <= right.length; rightIndex++) {
      current[rightIndex] = Math.min(
        current[rightIndex - 1] + 1,
        previous[rightIndex] + 1,
        previous[rightIndex - 1] + (left[leftIndex - 1] === right[rightIndex - 1] ? 0 : 1),
      )
    }
    previous.splice(0, previous.length, ...current)
  }
  return previous[right.length]
}

function getCloseMatches(query: string, answers: string[]) {
  const normalizedQuery = normalizeAnswer(query)
  if (normalizedQuery.length < 3) return []
  return answers
    .map((answer) => {
      const normalizedAnswer = normalizeAnswer(answer)
      const longest = Math.max(normalizedQuery.length, normalizedAnswer.length)
      const similarity = 1 - editDistance(normalizedQuery, normalizedAnswer) / longest
      return { answer, similarity, lengthDelta: Math.abs(normalizedQuery.length - normalizedAnswer.length) }
    })
    .filter(({ similarity, lengthDelta }) => similarity >= .72 && lengthDelta <= Math.max(3, Math.ceil(normalizedQuery.length * .3)))
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 3)
    .map(({ answer }) => answer)
}

function HolyMackerel() {
  return (
    <div className="holy-mackerel" role="status">
      <Image src="/game-assets/holy-mackerel.png" alt="Holy Mackerel" width={249} height={129} unoptimized />
      <div><strong>Holy Mackerel!</strong><span>Congratulations! You entered the number 1 answer!</span></div>
    </div>
  )
}

function classifyAnswer(value: string, question: Question): Answer {
  const clean = value.trim()
  const normalizedClean = normalizeAnswer(clean)
  let answerIndex = -1
  question.answers.forEach((answer, index) => {
    if (normalizeAnswer(answer) === normalizedClean) answerIndex = index
  })
  if (answerIndex >= 0) {
    const percentile = question.answers.length === 1 ? 1 : answerIndex / (question.answers.length - 1)
    const points = 4 + Math.round(percentile * 21)
    const rarity: Rarity = points <= 8 ? 'common' : points <= 14 ? 'rare' : points <= 20 ? 'epic' : 'legendary'
    const reaction = rarity === 'legendary'
      ? 'A deep-cut answer from the farthest reaches of the ledger!'
      : rarity === 'epic'
        ? 'An impressively niche answer!'
        : rarity === 'rare'
          ? 'A clever answer—not many sailors know that one.'
          : 'A valid answer. The reel is moving!'
    return { name: question.answers[answerIndex], points, rarity, reaction, valid: true }
  }
  return {
    name: clean,
    points: 0,
    rarity: 'common',
    reaction: 'That answer is not in this question’s ledger. The reel stays put.',
    valid: false,
  }
}

function StyleGuide({ onClose }: { onClose: () => void }) {
  return (
    <div className="overlay">
      <div className="guide">
        <div className="guide-head">
          <div><span className="kicker">REEL KNOWLEDGE UI KIT</span><h2>Pixel system</h2></div>
          <button className="close-button" onClick={onClose} aria-label="Close style guide">×</button>
        </div>
        <div className="guide-grid">
          <section><h3>Rarity language</h3><div className="tag-stack">{(['common', 'rare', 'epic', 'legendary'] as Rarity[]).map(r => <RarityTag key={r} rarity={r} />)}</div><p>Color, label, border and weight work together—never color alone.</p></section>
          <section><h3>Typography</h3><div className="type-sample">Giant Oarfish</div><p>Fraunces-inspired display serif / friendly humanist sans body.</p></section>
          <section><h3>Controls</h3><div className="button-stack"><GameButton>Primary action</GameButton><GameButton variant="secondary">Secondary</GameButton><GameButton disabled>Disabled</GameButton></div></section>
          <section><h3>Input states</h3><input className="answer-input" placeholder="Default input" /><input className="answer-input is-error" value="" readOnly placeholder="Required field" /><p>56px controls, 8px spacing rhythm, 16–24px rounded corners.</p></section>
          <section className="swatches"><h3>Core palette</h3><div><i className="swatch swatch--sand" />Sunlit sand</div><div><i className="swatch swatch--ocean" />Ocean teal</div><div><i className="swatch swatch--navy" />Deep navy</div><div><i className="swatch swatch--gold" />Neptune gold</div></section>
          <section><h3>Motion</h3><p>Soft bobbing, wave drift, sparkles, and short score bursts. Reduced-motion preferences are respected.</p></section>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('title')
  const [question, setQuestion] = useState(0)
  const [value, setValue] = useState('')
  const [error, setError] = useState('')
  const [answers, setAnswers] = useState<Answer[]>([])
  const [guideOpen, setGuideOpen] = useState(false)
  const [inventoryOpen, setInventoryOpen] = useState(false)
  const [inventory, setInventory] = useState<InventoryCatch[]>([])
  const [correction, setCorrection] = useState<Correction | null>(null)
  const [soundOn, setSoundOn] = useState(true)
  const [demoMode, setDemoMode] = useState(false)
  const [targetIndex, setTargetIndex] = useState(0)
  const [roundQuestions, setRoundQuestions] = useState(() => questionBank.slice(0, 3))
  const playerToken = useRef('')
  const savedRound = useRef(false)
  const hasStarted = useRef(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null)
  const audioFilterRef = useRef<BiquadFilterNode | null>(null)
  const playedSoundEventRef = useRef('')
  const activeEffectRef = useRef<HTMLAudioElement | null>(null)
  const clickAudioRef = useRef<HTMLAudioElement | null>(null)
  const coolerAudioRef = useRef<HTMLAudioElement | null>(null)
  const demoRoundRef = useRef(0)
  const target = targets[targetIndex]
  const latest = answers[answers.length - 1]
  const points = useMemo(() => answers.reduce((sum, item) => sum + item.points, 0), [answers])

  useEffect(() => {
    if (screen !== 'evaluating') return
    const timer = window.setTimeout(() => setScreen('feedback'), 1500)
    return () => window.clearTimeout(timer)
  }, [screen])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    audio.volume = .42
    audio.load()
    clickAudioRef.current?.load()
    coolerAudioRef.current?.load()
    return () => {
      audio.pause()
      audio.currentTime = 0
      activeEffectRef.current?.pause()
      const context = audioContextRef.current
      if (context && context.state !== 'closed') void context.close()
      audioContextRef.current = null
      audioSourceRef.current = null
      audioFilterRef.current = null
    }
  }, [])

  useEffect(() => {
    const underwater = underwaterScreens.includes(screen)
    const audio = audioRef.current
    const context = audioContextRef.current
    const filter = audioFilterRef.current
    if (audio) audio.volume = underwater ? .13 : .42
    if (context && filter) {
      filter.frequency.setTargetAtTime(underwater ? 620 : 18000, context.currentTime, .12)
    }
  }, [screen])

  useEffect(() => {
    if (screen !== 'casting') return
    const timer = window.setTimeout(() => setScreen('intro'), 3600)
    return () => window.clearTimeout(timer)
  }, [screen])

  useEffect(() => {
    let token = window.localStorage.getItem('tidebrain-player')
    if (!token) {
      token = crypto.randomUUID()
      window.localStorage.setItem('tidebrain-player', token)
    }
    playerToken.current = token
    getInventory(token).then(setInventory).catch(() => setInventory([]))
  }, [])

  useEffect(() => {
    if (screen !== 'result' || points < target.threshold || savedRound.current || !playerToken.current) return
    savedRound.current = true
    saveCatch({ playerToken: playerToken.current, fishName: target.name, rarity: target.rarity, points, threshold: target.threshold })
      .then((caught) => caught && setInventory((current) => [caught, ...current]))
      .catch(() => { savedRound.current = false })
  }, [screen, points, target])

  const ensureAudio = async () => {
    const audio = audioRef.current
    if (!audio) return
    if (!audioContextRef.current) {
      const context = new AudioContext()
      const source = context.createMediaElementSource(audio)
      const filter = context.createBiquadFilter()
      filter.type = 'lowpass'
      filter.Q.value = .8
      source.connect(filter).connect(context.destination)
      audioContextRef.current = context
      audioSourceRef.current = source
      audioFilterRef.current = filter
    }
    const context = audioContextRef.current
    const underwater = underwaterScreens.includes(screen)
    audio.volume = underwater ? .13 : .42
    audioFilterRef.current?.frequency.setValueAtTime(underwater ? 620 : 18000, context.currentTime)
    if (context.state === 'suspended') await context.resume()
    if (audio.paused) await audio.play()
  }

  const toggleSound = () => {
    const audio = audioRef.current
    if (soundOn) {
      audio?.pause()
      activeEffectRef.current?.pause()
      activeEffectRef.current = null
      setSoundOn(false)
    } else {
      setSoundOn(true)
      void ensureAudio()
    }
  }

  const playUiSound = (source: '/game-assets/click.mp3' | '/game-assets/cooler.mp3') => {
    if (!soundOn) return
    void ensureAudio()
    const effect = source.endsWith('click.mp3') ? clickAudioRef.current : coolerAudioRef.current
    if (!effect) return
    effect.pause()
    effect.currentTime = 0
    effect.volume = .78
    effect.play().catch(() => {
      // UI sounds require a browser-permitted interaction.
    })
  }

  const begin = () => {
    setQuestion(0); setAnswers([]); setValue(''); setError(''); setCorrection(null); savedRound.current = false
    const isFirstRound = !hasStarted.current
    const demoRarities: Rarity[] = ['epic', 'common', 'legendary']
    const forcedRarity = demoMode ? demoRarities[demoRoundRef.current % demoRarities.length] : undefined
    setTargetIndex((current) => rollTarget(current, !isFirstRound, forcedRarity))
    if (demoMode) demoRoundRef.current += 1
    hasStarted.current = true
    setRoundQuestions([...questionBank].sort(() => Math.random() - .5).slice(0, 3))
    setScreen('casting')
  }

  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (!value.trim()) {
      setError('The sea is silent—type a fish name first.')
      return
    }
    const answer = classifyAnswer(value, roundQuestions[question])
    if (!answer.valid) {
      const matches = getCloseMatches(value, roundQuestions[question].answers)
      if (matches.length) {
        setCorrection({ query: value.trim(), matches })
        return
      }
    }
    setAnswers(current => [...current, answer])
    setError('')
    setCorrection(null)
    setScreen('evaluating')
  }

  const confirmCorrection = (accepted: boolean) => {
    if (!correction) return
    const answer = classifyAnswer(accepted ? correction.matches[0] : correction.query, roundQuestions[question])
    setAnswers(current => [...current, answer])
    setValue(accepted ? correction.matches[0] : correction.query)
    setCorrection(null)
    setScreen('evaluating')
  }

  const continueFromFeedback = () => setScreen('reeling')
  const continueFromReeling = () => {
    if (points >= target.threshold || question === 2) setScreen('result')
    else {
      setQuestion(current => current + 1)
      setValue('')
      setCorrection(null)
      setScreen('question')
    }
  }

  const isGame = !['title', 'casting', 'intro', 'result'].includes(screen)
  const won = points >= target.threshold
  const pose = screen === 'evaluating' ? 'thinking' : screen === 'feedback' ? (latest?.points >= 15 ? 'happy' : 'asking') : screen === 'reeling' ? (points >= 60 ? 'happy' : 'asking') : 'asking'

  useEffect(() => {
    let eventKey = ''
    let source = ''
    if (screen === 'question' && question === 0 && answers.length === 0) {
      eventKey = `start-${target.name}`
      source = soundEffects.start
    } else if (screen === 'feedback' && latest) {
      eventKey = `feedback-${question}-${answers.length}-${latest.name}`
      source = latest.points === 25
        ? soundEffects.perfect
        : latest.points === 0
          ? soundEffects.zero
          : latest.points <= 14
            ? soundEffects.good
            : soundEffects.great
    } else if (screen === 'result') {
      eventKey = `result-${target.name}-${answers.length}-${won ? 'won' : 'lost'}`
      source = won ? soundEffects.success : soundEffects.failed
    }
    if (!eventKey || eventKey === playedSoundEventRef.current) return
    playedSoundEventRef.current = eventKey
    activeEffectRef.current?.pause()
    activeEffectRef.current = null
    if (!soundOn) return
    const effect = new Audio(source)
    effect.volume = .78
    activeEffectRef.current = effect
    effect.onended = () => {
      if (activeEffectRef.current === effect) activeEffectRef.current = null
    }
    effect.play().catch(() => {
      // Sound effects wait for a browser-permitted interaction when necessary.
    })
  }, [answers.length, latest, question, screen, soundOn, target.name, won])

  return (
    <main className={`app app--${screen}`}>
      <div className="sky">
        <div className="sun" />
        <div className="cloud cloud--one" />
        <div className="cloud cloud--two" />
        <div className="island island--one" />
        <div className="island island--two" />
      </div>
      <div className="ocean"><div className="wave wave--one" /><div className="wave wave--two" /></div>
      <div className="beach"><div className="shell shell--one">✦</div><div className="shell shell--two">⌁</div></div>

      {screen === 'title' && (
        <div className="title-screen">
          <div className="title-copy">
            <h1>Reel <span>Knowledge</span></h1>
            <div className="how-to">
              <span>1</span><p><strong>Answer 3 questions</strong><br />with a fish name</p>
              <i />
              <span>2</span><p><strong>Earn rarity points</strong><br />for obscure answers</p>
              <i />
              <span>3</span><p><strong>Beat the threshold</strong><br />and reel it in</p>
            </div>
            <div className="title-actions"><GameButton onClick={() => { playUiSound('/game-assets/click.mp3'); begin() }}>Start fishing <span aria-hidden="true">→</span></GameButton><GameButton variant="ghost" onClick={() => { playUiSound('/game-assets/click.mp3'); setGuideOpen(true) }}>View UI kit</GameButton></div>
          </div>
          <Neptune pose="greeting" />
          <div className="title-cooler"><CoolerButton count={inventory.length} onClick={() => { playUiSound('/game-assets/cooler.mp3'); setInventoryOpen(true) }} /></div>
        </div>
      )}

      {screen === 'title' && (
        <button
          className={`demo-toggle ${demoMode ? 'demo-toggle--active' : ''}`}
          onClick={() => {
            playUiSound('/game-assets/click.mp3')
            setDemoMode((current) => !current)
            demoRoundRef.current = 0
          }}
          type="button"
        >
          <span>DEMO MODE</span>
          <strong>{demoMode ? 'ON' : 'OFF'}</strong>
        </button>
      )}

      {screen === 'casting' && <CastingSequence target={target} />}

      {screen === 'intro' && (
        <div className="scene scene--intro">
          <div className="teleport-flash"><span>✦</span><span>✦</span><span>✦</span></div>
          <Rod state="cast" />
          <Neptune pose="casting" />
          <Dialogue eyebrow="KING NEPTUNE · RULER OF THE DEEP">
            <span className="hooked-label">HOOKED!</span>
            <h2>{target.name}</h2>
            <div className="hooked-target"><RarityTag rarity={target.rarity} /><strong>{target.threshold} points needed to reel it in</strong></div>
            <p>Answer three questions. Every valid answer pulls the line closer to the surface.</p>
            <GameButton onClick={() => setScreen('question')}>I’m ready</GameButton>
          </Dialogue>
        </div>
      )}

      {isGame && <Hud points={points} question={question} target={target} onInventory={() => setInventoryOpen(true)} count={inventory.length} />}

      {screen === 'question' && (
        <div className="scene scene--game">
          <UnderwaterLine target={target} points={points} />
          <Rod state="idle" />
          <Neptune pose="asking" />
          <Dialogue eyebrow={`QUESTION ${question + 1} OF 3`}>
            <h2>{roundQuestions[question].prompt}</h2>
            <form onSubmit={submit}>
              <label htmlFor="fish-answer">Your fish answer</label>
              <div className="input-row">
                <input id="fish-answer" autoFocus disabled={!!correction} maxLength={40} className={`answer-input ${error ? 'is-error' : ''}`} value={value} onChange={e => { setValue(e.target.value); setError(''); setCorrection(null) }} placeholder="Type your answer" />
                <GameButton type="submit" disabled={!!correction}>Submit answer</GameButton>
              </div>
              <div className="input-meta"><span className={error ? 'error-text' : ''}>{error || 'Be specific—obscure answers score more.'}</span><span>{value.length}/40</span></div>
              {correction && (
                <div className="correction-box">
                  <span>NO EXACT MATCH</span>
                  <strong>Did you mean “{correction.matches[0]}”?</strong>
                  {correction.matches.length > 1 && <small>Other close matches: {correction.matches.slice(1).join(' · ')}</small>}
                  <div><GameButton onClick={() => confirmCorrection(true)}>Yes, use it</GameButton><GameButton variant="secondary" onClick={() => confirmCorrection(false)}>No</GameButton></div>
                </div>
              )}
            </form>
          </Dialogue>
        </div>
      )}

      {screen === 'evaluating' && (
        <div className="scene scene--game">
          <UnderwaterLine target={target} points={points} />
          <Rod state="idle" /><Neptune pose="thinking" />
          <Dialogue eyebrow="THE VERDICT">
            <div className="judging"><div className="orb"><i /><i /><i /></div><div><h2>King Neptune is judging...</h2><p>Searching the deepest corners of the fish database for <strong>“{latest?.name}”</strong></p></div></div>
          </Dialogue>
        </div>
      )}

      {screen === 'feedback' && latest && (
        <div className={`scene scene--game feedback feedback--${latest.rarity}`}>
          <UnderwaterLine target={target} points={points} />
          {latest.points === 25 && <HolyMackerel />}
          <Rod state="idle" /><Neptune pose={latest.points >= 15 ? 'happy' : 'asking'} />
          <Dialogue eyebrow="NEPTUNE’S VERDICT">
            <div className="feedback-line"><div><span className="mini-label">YOUR ANSWER</span><h2 className="fish-name">{latest.name}</h2>{latest.valid ? <RarityTag rarity={latest.rarity} /> : <span className="rarity rarity--invalid">NOT A VALID FISH</span>}</div><div className={`points-pop ${latest.valid ? '' : 'points-pop--zero'}`}>+{latest.points}<small>PTS</small></div></div>
            <p className="reaction">“{latest.reaction}”</p>
            <GameButton onClick={continueFromFeedback}>Add to rod power</GameButton>
          </Dialogue>
        </div>
      )}

      {screen === 'reeling' && (
        <div className="scene scene--game">
          <UnderwaterLine target={target} points={points} />
          <Rod state={points >= target.threshold ? 'caught' : 'tension'} /><Neptune pose={points >= target.threshold ? 'happy' : 'asking'} />
          <Dialogue eyebrow="LINE TENSION">
            <h2>{points >= target.threshold ? 'The line is surging!' : latest?.points === 0 ? 'The line didn’t move.' : question === 2 ? 'One last pull...' : 'Your rod grows stronger!'}</h2>
            <ProgressMeter points={points} threshold={target.threshold} />
            <p>{points >= target.threshold ? `You crossed the ${target.rarity} threshold. Hold tight!` : `${Math.max(0, target.threshold - points)} more points needed to land the ${target.name}.`}</p>
            <GameButton onClick={continueFromReeling}>{points >= target.threshold || question === 2 ? 'Reel it in' : 'Next question'}</GameButton>
          </Dialogue>
        </div>
      )}

      {screen === 'result' && (
        <div className={`result result--${won ? 'catch' : 'miss'}`}>
          <div className="result-card">
            <span className="kicker">{won ? 'LEGENDARY CATCH' : 'SO CLOSE'}</span>
            <h2>{won ? 'You reeled it in!' : 'The fish got away...'}</h2>
            <div className="result-fish">{target.name}</div>
            <RarityTag rarity={target.rarity} />
            <ProgressMeter points={points} threshold={target.threshold} />
            <ScoreBreakdown answers={answers} />
            <p className="result-note">{won ? `Added to your cooler with a brilliant ${points}-point catch.` : `You earned ${points} of ${target.threshold} points. Neptune has moved your rod to a new target.`}</p>
            <div className="result-actions"><GameButton onClick={() => { playUiSound('/game-assets/click.mp3'); begin() }}>{won ? 'Fish again' : 'Find a new target'}</GameButton><GameButton variant="secondary" onClick={() => { playUiSound('/game-assets/click.mp3'); setScreen('title') }}>Back to the beach</GameButton><CoolerButton count={inventory.length} onClick={() => { playUiSound('/game-assets/cooler.mp3'); setInventoryOpen(true) }} /></div>
          </div>
          <Neptune pose={won ? 'happy' : 'sad'} />
          <Rod state={won ? 'caught' : 'slack'} />
        </div>
      )}

      <audio ref={audioRef} src="/game-assets/reel-knowledge-theme.mp3" loop preload="auto" />
      <audio ref={clickAudioRef} src="/game-assets/click.mp3" preload="auto" />
      <audio ref={coolerAudioRef} src="/game-assets/cooler.mp3" preload="auto" />
      <button className="sound-pill" onClick={toggleSound} type="button" aria-label={soundOn ? 'Turn sound off' : 'Turn sound on'}>{soundOn ? '♪' : '×'} <span>Sound {soundOn ? 'on' : 'off'}</span></button>
      {guideOpen && <StyleGuide onClose={() => setGuideOpen(false)} />}
      {inventoryOpen && <Inventory items={inventory} onClose={() => setInventoryOpen(false)} />}
    </main>
  )
}
